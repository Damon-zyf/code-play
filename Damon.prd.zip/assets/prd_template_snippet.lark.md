
这是一个 PRD 文档中常见元素的格式片段，你可以参考或复制这里的语法来构建你的文档。

### `Intro & Goal // 背景与目标`

<callout icon="bulb" bgc="3">
  **Why build it? // 需求背景**
  - 这里简述项目启动的原因，例如：当前用户流失率因 XXX 问题上升了 20%。
  - 我们的目标是通过优化 XXX 流程，将流失率降低 10%。
</callout>

### `Success Metrics // 衡量指标`

<table header-row="true" col-widths="150,300,150">
    <tr>
        <td>**Metric Type**</td>
        <td>**Metric Name**</td>
        <td>**Target**</td>
    </tr>
    <tr>
        <td>Goal Metric</td>
        <td>用户功能采纳率 (Adoption Rate)</td>
        <td>> 30%</td>
    </tr>
    <tr>
        <td>Guardrail Metric</td>
        <td>页面平均加载时间 (Avg. Load Time)</td>
        <td>< 2s</td>
    </tr>
</table>

### `Product Flow // 产品流程`

![preview](your_flow_diagram.drawio)
> **注意**: 上述 `your_flow_diagram.drawio` 需要你替换为自己创建的真实图表文件。
