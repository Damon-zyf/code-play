
## Lark/Feishu Markdown 写作风格指南要点

本指南提供核心的 Lark/Feishu Markdown 格式化建议，以帮助你创建表达丰富且专业的文档。

### 核心格式化工具

#### 1. 表格 (`<table>`)
用于展示结构化数据。**必须**使用 HTML `<table>` 语法，Markdown 管道表格 `|` 不被支持。

**示例：**
```html
<table header-row="true" col-widths="100,404,116">
    <tr>
        <td>**Date**</td>
        <td>**Description**</td>
        <td>**Version**</td>
    </tr>
    <tr>
        <td>2025/03/26</td>
        <td>Initial draft for the new feature.</td>
        <td>v1.0</td>
    </tr>
</table>
```

#### 2. 突出显示块 (`<callout>`)
用于强调关键信息、警告或注释。

- `icon`: 设置图标 (如 `bulb`, `warning`, `pushpin`)
- `bgc`: 设置背景颜色 (1-15 的数字，如 `3` 代表浅黄色)

**示例：**
```markdown
<callout icon="bulb" bgc="3">
  **核心决策**: 为了加快上线速度，第一版将不支持自定义配置功能。
</callout>

<callout icon="warning" bgc="1">
  **风险提示**: 此项变更会影响现有 API 的返回值结构，请下游团队务必同步改造。
</callout>
```

#### 3. 图表与流程图 (嵌入文件)
对于流程图、架构图等，应创建为独立文件，然后嵌入到文档中。这会渲染为可交互、可编辑的飞书画板。

- **Draw.io**: `.drawio` 文件，用于通用流程图、线框图。
- **PlantUML**: `.puml` 文件，用于时序图、状态机图。

**嵌入语法：**
```markdown
![preview](path/to/your/diagram.drawio)
![preview](path/to/your/state_machine.puml)
```

#### 4. 文本样式
- **加粗**: `**重要内容**`
- **颜色**: `<font color="red">待确认的内容</font>` (支持 `red`, `green`, `blue` 等)

### 最佳实践

1.  **结构先行**: 在动笔前，先用 H2/H3 标题规划好文档的骨架。
2.  **适当留白**: 在表格、Callout、图片等元素之间保留空行，让版面更清爽。
3.  **组合使用**: 可以在 `<table>` 的单元格或者 `<callout>` 内部使用列表、加粗等标准 Markdown 语法，来组织更复杂的信息。
4.  **一致性**: 在整篇文档中保持统一的风格，例如，所有风险提示都使用同一种颜色的 Callout。
