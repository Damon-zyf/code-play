
import argparse
import os

def create_prd_outline(product_name: str, goal: str, output_file: str):
    """
    Generates a PRD outline in Lark Markdown format.
    """
    content = f"""
## Basic Info // 基本信息

<table header-row="true" col-widths="100,404,116">
    <tr>
        <td>**Date**</td>
        <td>**Description**</td>
        <td>**Version**</td>
    </tr>
    <tr>
        <td>{os.popen('date +%Y/%m/%d').read().strip()}</td>
        <td>PRD Draft for {product_name}</td>
        <td>v1.0</td>
    </tr>
</table>

## Intro & Goal // 背景与目标

### What are we building? // 需求概述
本项目旨在为 **{product_name}** 实现 **{goal}**。

### Why build it? // 需求背景
<callout icon="pushpin" bgc="5">
**背景:**
- [待填充: 当前存在的问题或机遇]

**目标:**
- [待填充: 希望通过本项目达成的具体业务目标]
</callout>

### Success Metrics // 衡量指标
<table header-row="true" col-widths="150,300,150">
    <tr>
        <td>**Metric Type**</td>
        <td>**Metric Name**</td>
        <td>**Target**</td>
    </tr>
    <tr>
        <td>Goal Metric</td>
        <td>[待填充]</td>
        <td>[待填充]</td>
    </tr>
    <tr>
        <td>Guardrail Metric</td>
        <td>[待填充]</td>
        <td>[待填充]</td>
    </tr>
</table>

## Requirement Detail // 需求详情

### Product Flow // 产品流程
[待填充: 建议使用 Draw.io 或 PlantUML 绘制流程图并在此处嵌入]
`![preview](flow_diagram.drawio)`

### Feature Details // 功能详述
#### 功能点一：[待填充]
- **描述**: [待填充]
- **业务规则**: [待填充]

"""
    try:
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"✅ PRD outline created at: {output_file}")
    except IOError as e:
        print(f"❌ Error writing to file {output_file}: {e}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate a PRD outline.")
    parser.add_argument("--product", type=str, required=True, help="The name of the product.")
    parser.add_argument("--goal", type=str, required=True, help="The primary goal of the PRD.")
    parser.add_argument("--output", type=str, default="outline.lark.md", help="Output file name.")
    args = parser.parse_args()

    create_prd_outline(args.product, args.goal, args.output)
