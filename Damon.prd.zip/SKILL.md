---
name: standard-prd-writer
description: 协助产品经理撰写结构清晰、格式丰富、符合专业标准的 PRD (产品需求文档)。支持从零开始或基于现有需求，生成包含中英双语标题、表格、图表和关键信息高亮的 Lark/Feishu 文档。适用于任何需要编写或优化 PRD 的场景。
---
# Standard PRD Writer

本 Skill 用于协助产品经理撰写一份专业、结构化且表达丰富的 PRD (产品需求文档)。

## 核心写作指导

撰写 PRD 时，应遵循“Why -> What -> How”的逻辑主线，但不必拘泥于固定模板。核心是清晰地传达产品目标、范围和具体需求。

### 1. 柔性结构
PRD 的结构应根据产品需求的复杂性和上下文动态组织。以下是一个推荐的通用结构，但你可以根据实际情况自由增删或调整章节顺序：

- **H2: Basic Info // 基本信息**: 包括文档修订历史、相关链接等。
- **H2: Intro & Goal // 背景与目标**:
  - `Why build it? // 需求背景`: 解释项目起因、要解决的问题和商业价值。
  - `What are we building? // 需求概述`: 高层次总结产品要实现的功能。
  - `Success Metrics // 衡量指标`: 定义产品成功的关键指标。
- **H2: Requirement Detail // 需求详情**:
  - `Product Flow // 产品流程`: 详细描述用户流程和系统交互。
  - `Feature XXX // 功能点详述`: 对每个功能点进行详细说明。
- **H2: Impact & Risk // 影响与风险**: 分析对现有系统的影响、依赖关系和潜在风险。

### 2. 写作风格与格式化
一份优秀的 PRD 需要善用格式化工具来提升可读性。

- **标题层级与双语**:
  - 使用 H2, H3, H4 构建清晰的文档层级。
  - 推荐在各级标题中使用 `英文标题 // 中文标题` 的双语风格，以适应国际化协作环境。

- **富文本运用**:
  - **表格 (`<table>`)**: 用于呈现结构化数据，如版本记录、需求列表、影响范围、衡量指标等。**必须**使用 HTML `<table>` 语法。
  - **Callout (`<callout>`)**: 用于高亮突出 **关键背景、核心原则、重要决策、风险提示** 等需要读者特别关注的信息。
  - **图表与流程图**: 对于复杂的流程（如用户旅程、状态机、系统架构），应创建独立的 `.drawio` 或 `.puml` 文件，并使用 `![preview](path/to/diagram.drawio)` 嵌入文档。这将在 Lark/Feishu 中渲染为可编辑的画板。

- **重点突出**:
  - 使用**粗体** (`**text**`) 来强调文档中的关键术语、功能名称、角色和核心数据。
  - 使用字体颜色 (`<font color="red">text</font>`) 来警示风险或标记待定项 (TBD)。

## 资源引用说明

为了更好地辅助你完成 PRD 撰写，本 Skill 提供了以下资源：

- **`references/prd_style_guide.lark.md`**: 提供了更详细的 PRD 写作方法论和最佳实践，包括如何组织内容、如何撰写有效的需求描述等。在你开始撰写前，建议先阅读此文档。
- **`references/lark_markdown_guide.lark.md`**: Lark/Feishu Markdown 的速查手册，当你需要使用特定格式（如表格、Callout）但又不确定语法时，可以参考此文档。
- **`assets/prd_template_snippet.lark.md`**: 提供了一个包含多种格式元素的 `.lark.md` 模板片段。它不是一个强制的结构，而是一个格式参考，你可以从中复制语法，灵活运用到你的文档中。
- **`scripts/create_outline.py`**: 一个可选的 Python 辅助脚本。运行 `python3 scripts/create_outline.py --product "你的产品名" --goal "你的目标"` 可以快速生成一个包含基本章节的 PRD 大纲文件 (`outline.lark.md`)，帮助你快速启动。

## 输出要求

- **默认输出**: 你的主要任务是生成一份完整的 `.lark.md` 文件。
- **语言**: 默认使用中文作为主要写作语言，但鼓励在标题和关键术语上保持中英双语。
- **最终交付**: 在完成 `.lark.md` 文件后，调用 `mcp_lark_create_lark_doc` 工具将其转换为正式的 Lark/Feishu 文档。
